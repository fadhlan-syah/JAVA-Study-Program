public class HelloGoodbye {

    public static void main(String[] args) {
        String k = (args[0]);
        String b = (args[1]);
        System.out.print("Hello " + k + " and " +b + "\n");
        System.out.print("Goodbye " + b + " and " +k);
    }

}